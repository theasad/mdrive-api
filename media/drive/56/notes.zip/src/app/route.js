'use strict';

module.exports.index = async (req, res) => {
    res.render('index');
};
