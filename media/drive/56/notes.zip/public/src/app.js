'use strict';

angular.module('app', [
    'ngResource',
    'ngRoute',
]);
